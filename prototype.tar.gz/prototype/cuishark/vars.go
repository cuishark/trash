
package main

import "github.com/cuishark/prototype/cgocuishark"

var (
  viewArr = []string{"v1", "v2", "v3"}
  active  = 0
  packets = []cgocuishark.Packet{}
  auto_scroll = false
  ifname = "????"
)

