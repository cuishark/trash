
package main

import (
	"./cuishark"
)

func main() {
	ui := cuishark.NewUI()
	ui.Ui.SetKeybinding("Esc"   , func() { ui.ModeChange(cuishark.Normal)  })

	ui.Ui.SetKeybinding("Ctrl+p", func() { ui.PacketPane.ScrollUp  ()      })
	ui.Ui.SetKeybinding("Ctrl+n", func() { ui.PacketPane.ScrollDown()      })
	ui.Ui.SetKeybinding("Up"    , func() { ui.PacketPane.ScrollUp  ()      })
	ui.Ui.SetKeybinding("Down"  , func() { ui.PacketPane.ScrollDown()      })

	ui.Ui.SetKeybinding(":"     , func() { ui.ModeChange(cuishark.Command) })
	ui.Ui.SetKeybinding("Ctrl+c", func() { ui.ModeChange(cuishark.Normal ) })
	ui.Ui.SetKeybinding("Ctrl+d", func() { ui.Quit() })

	if err := ui.Run(); err != nil {
		panic(err)
	}
}
