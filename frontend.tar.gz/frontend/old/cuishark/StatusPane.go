
package cuishark

import (
	"github.com/marcusolsson/tui-go"
)

type StatusPane struct {
	ModeLabel *tui.Label
	TargetLabel *tui.Label
	Input *tui.Entry
	InputBox *tui.Box
}

func NewStatusPane() *StatusPane {
	pane := StatusPane{}
	pane.Input = tui.NewEntry()
	pane.Input.SetFocused(false)
	pane.Input.SetSizePolicy(tui.Expanding, tui.Maximum)

	pane.ModeLabel = tui.NewLabel("Normal")
	pane.ModeLabel.SetSizePolicy(tui.Minimum, tui.Minimum)
	pane.TargetLabel = tui.NewLabel("in.pcap")
	pane.TargetLabel.SetSizePolicy(tui.Expanding, tui.Expanding)
	space := tui.NewLabel(" ")
	space.SetSizePolicy(tui.Minimum, tui.Minimum)
	line := tui.NewHBox(pane.ModeLabel, space, pane.TargetLabel)
	pane.InputBox = tui.NewVBox(
		line,
		pane.Input,
	)
	pane.InputBox.SetBorder(true)
	pane.InputBox.SetSizePolicy(tui.Expanding, tui.Maximum)
	return &pane
}

func (pane *StatusPane) FocusOn() {
	pane.Input.SetFocused(true)
	pane.ModeLabel.SetStyleName("command")
}
func (pane *StatusPane) FocusOff() {
	pane.Input.SetText("")
	pane.Input.SetFocused(false)
}

