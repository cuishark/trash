

package cuishark

import (
	"fmt"
	"github.com/marcusolsson/tui-go"
)

type State int
const (
	Normal State = iota
	Detail
	Command
)

func (s State) String() string {
	switch (s) {
	case Normal:
		return "Normal"
	case Detail:
		return "Detail"
	case Command:
		return "Command"
	default:
		return "unknown"
	}
}

type UI struct {
	state State
	Ui tui.UI
	Root *tui.Box
	PacketPane *PacketPane
	StatusPane *StatusPane
}

func NewUI() UI {
	ui := UI{}
	ui.state = Normal
	ui.PacketPane = NewPacketPane()
	ui.StatusPane = NewStatusPane()

	ui.Root = tui.NewVBox(
		ui.PacketPane.ListBox,
		ui.StatusPane.InputBox)
	ui.Root.SetSizePolicy(tui.Expanding, tui.Expanding)

	tui_ui, err := tui.New(ui.Root)
	if err != nil {
		panic(err)
	}

	t := tui.NewTheme()
	t.SetStyle("label.normal" , tui.Style{Bg:tui.ColorCyan , Fg:tui.ColorWhite})
	t.SetStyle("label.command", tui.Style{Bg:tui.ColorGreen, Fg:tui.ColorWhite})
	tui_ui.SetTheme(t)

	ui.Ui = tui_ui
	ui.ModeChange(Normal)
	return ui
}

func (ui *UI) Run() error {
	err := ui.Ui.Run()
	return err
}

func (ui *UI) Quit() {
	ui.Ui.Quit()
}

func (ui *UI) modeReaveNormal() {

}

func (ui *UI) modeChangeNormal() {
	ui.StatusPane.ModeLabel.SetStyleName("normal")
}

func (ui *UI) modeReaveCommand() {
	ui.StatusPane.FocusOff()
}

func (ui *UI) modeChangeCommand() {
	ui.StatusPane.FocusOn()
}

func (ui *UI) ModeChange(next State) {
	switch (ui.state) {
	case Command:
		ui.modeReaveCommand()
	case Normal:
		ui.modeReaveNormal()
	}

	ui.state = next
	switch (ui.state) {
	case Command:
		ui.modeChangeCommand()
	case Normal:
		ui.modeChangeNormal()
	}
	str := fmt.Sprintf(" %s ", next.String())
	ui.StatusPane.ModeLabel.SetText(str)
}



