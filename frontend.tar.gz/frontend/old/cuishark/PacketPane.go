
package cuishark

import (
	"fmt"
	"github.com/marcusolsson/tui-go"
)

type PacketPane struct {
	List *tui.Box
	ListScroll *tui.ScrollArea
	ListBox *tui.Box
}

func NewPacketPane() *PacketPane {
	pane := PacketPane{}
	pane.List = tui.NewVBox()
	for i:=0; i<10; i++ {
		pane.List.Append(tui.NewVBox(
			tui.NewLabel(fmt.Sprintf("libwireshark mo muri, cgo ga yoku wakaran mendoi slankdev %d", i)),
		))
	}

	pane.ListScroll = tui.NewScrollArea(pane.List)
	pane.ListScroll.SetAutoscrollToBottom(false)

	pane.ListBox = tui.NewVBox(pane.ListScroll)
	pane.ListBox.SetBorder(true)
	return &pane
}

func (pane *PacketPane) ScrollDown() {
	pane.ListScroll.Scroll(0, +1)
}

func (pane *PacketPane) ScrollUp() {
	pane.ListScroll.Scroll(0, -1)
}

