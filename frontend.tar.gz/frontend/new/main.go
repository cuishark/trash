package main

/*
#cgo pkg-config: glib-2.0
#cgo CFLAGS: -I../../prototype/backend/lib
#cgo LDFLAGS: -L../../prototype/backend/lib
#cgo LDFLAGS: -L/usr/local/lib
#cgo LDFLAGS: -lcuishark
#cgo LDFLAGS: -lwireshark -lgmodule-2.0
#cgo LDFLAGS: -pthread -lgthread-2.0 -pthread -lglib-2.0
#cgo LDFLAGS: -lwiretap -lwsutil -lz -lm -lpcap -lstdc++
#include <cuishark.h>
#include <hexdump.h>
*/
import "C"
import (
  "fmt"
  "log"
  "os"
  "github.com/jroimartin/gocui"
)

var (
  viewArr = []string{"v1", "v2", "v3"}
  active  = 0
  c = 0
  ypos_v2 = 0
  ypos_v3 = 0
  height_v2 = 0
  height_v3 = 0
)

type Widget struct {
  name           string
  body           string
  x0, y0, x1, y1 int
}

func layout(g *gocui.Gui) error {
  maxX, maxY := g.Size()
  v1 := &Widget{"v1", "Widget 1", 0, 0*(maxY/3-1)+0, maxX-1, 1*(maxY/3)-1 }
  v2 := &Widget{"v2", "Widget 2", 0, 1*(maxY/3-1)+1, maxX-1, 2*(maxY/3)-1 }
  v3 := &Widget{"v3", "Widget 2", 0, 2*(maxY/3-1)+2, maxX-1, 3*(maxY/3)-1 }

  f := func(w *Widget) {
    if _, err := g.SetView(w.name, w.x0, w.y0, w.x1, w.y1); err != nil {
      if err != gocui.ErrUnknownView {
        log.Panicln(err)
      }
    }
  }

  f(v1)
  f(v2)
  f(v3)
  return nil
}

func main() {
  g, err := gocui.NewGui(gocui.OutputNormal)
  if err != nil {
    log.Panicln(err)
  }
  defer g.Close()

  g.Cursor = true
  g.Highlight = true
  g.SelFgColor = gocui.ColorGreen
  g.SetManagerFunc(layout)

  if err := g.SetKeybinding("", gocui.KeyCtrlP, gocui.ModNone, scroll_up); err != nil { log.Panicln(err) }
  if err := g.SetKeybinding("", gocui.KeyCtrlN, gocui.ModNone, scroll_down); err != nil { log.Panicln(err) }
  if err := g.SetKeybinding("", gocui.KeyCtrlC, gocui.ModNone, quit); err != nil { log.Panicln(err) }
  if err := g.SetKeybinding("", gocui.KeyTab, gocui.ModNone, nextView); err != nil { log.Panicln(err) }

  argc := C.int(len(os.Args))
  argv := make([]*C.char, argc)
  for i, arg := range os.Args {
    argv[i] = C.CString(arg)
  }
  go C.cuishark_init(argc, (**C.char)(&argv[0]))

  go func() {
    for C.cuishark_loop_running() {
      v, err := g.View("v1")
      if err != nil { log.Panicln(err) }

      if (!C.cuishark_msg_queue_empty()) {

        m := C.cuishark_msgqueue_pop()
        n := C.cuishark_msg_node(m)

        s := C.GoString(C.node_line(n))
        fmt.Fprintf(v, "%s\n", s)
        // var i C.size_t
        // for i=0; i<C.node_childs_num(n); i++ {
        //   cn := C.node_child(n, i);
        //   C.print_csnode(cn, 0);
        // }
        // C.hexdump(C.stdout, C.cuishark_msg_data_ptr(m), C.cuishark_msg_data_len(m));
        // print("\n\n");

        g.Update(func(g *gocui.Gui) error { return nil })
      }
    }
    print("finish\n")
  }()

  if err := g.MainLoop(); err != nil && err != gocui.ErrQuit {
    log.Panicln(err)
  }
}

