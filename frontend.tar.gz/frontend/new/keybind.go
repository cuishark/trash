
package main

import (
  "fmt"
  // "log"
  "github.com/jroimartin/gocui"
)

func nextView(g *gocui.Gui, v *gocui.View) error {
  nextIndex := (active + 1) % len(viewArr)
  name := viewArr[nextIndex]

  v2, err := g.View("v2")
  if err != nil {
    return err
  }
  v3, err := g.View("v3")
  if err != nil {
    return err
  }
  fmt.Fprintf(v2, "%d Going from view to \n", c)
  fmt.Fprintf(v3, "%d v3v3v3 Going from view \n", c)
  c++

  if _, err := g.SetCurrentView(name); err != nil {
    return err
  }

  if nextIndex == 0 {
    g.Cursor = true
  } else {
    g.Cursor = false
  }

  active = nextIndex
  return nil
}

func scroll_up(g *gocui.Gui, v *gocui.View) error {
  nextIndex := (active) % len(viewArr)
  name := viewArr[nextIndex]
  v2, err := g.View(name)
  if err != nil {
    return err
  }

  ypos_v2 --
  if err := v2.SetOrigin(0, ypos_v2); err!= nil {
    ypos_v2 ++
  }
  return nil
}

func scroll_down(g *gocui.Gui, v *gocui.View) error {
  nextIndex := (active) % len(viewArr)
  name := viewArr[nextIndex]
  v2, err := g.View(name)
  if err != nil {
    return err
  }

  ypos_v2 ++
  if err := v2.SetOrigin(0, ypos_v2); err != nil {
    ypos_v2 --
  }
  return nil
}

func quit(g *gocui.Gui, v *gocui.View) error {
  return gocui.ErrQuit
}


